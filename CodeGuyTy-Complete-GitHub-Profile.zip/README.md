<div align="center">

<img src="assets/codeguyty-banner.png" alt="CodeGuyTy — Build, Learn, Improve, Repeat" width="100%" />

# Hey, I’m Tyler 👋

### Software Developer | Founder & Builder of WrenchFlow | Game Development Enthusiast

**💻 Software Development &nbsp; • &nbsp; 🔧 WrenchFlow &nbsp; • &nbsp; 🎮 Game Development &nbsp; • &nbsp; 📚 Always Learning**

[![GitHub](https://img.shields.io/badge/GitHub-codeguyty-101828?style=for-the-badge&logo=github&logoColor=white)](https://github.com/codeguyty)
[![Instagram](https://img.shields.io/badge/Instagram-%40CodeGuyTy-BC2A8D?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/codeguyty/)

</div>

---

<div align="center">

I’m a software developer with a background in industrial maintenance and mechanical systems. I enjoy building practical applications, solving real-world problems, and continuously improving my programming skills.

I’m currently developing **WrenchFlow**, a maintenance-management software project inspired by my experience working in industrial environments.

</div>

## 🚀 What I’m Working On

- 🔧 **WrenchFlow** — Designing and developing a maintenance-management platform for technicians, supervisors, and administrators.
- 💻 **CodeGuyTy** — Rebuilding my developer portfolio and documenting my software development journey.
- 🎮 **Game Development** — Exploring 2D game development with Phaser and Godot, with plans to expand into 3D.
- 📚 **Continued Learning** — Strengthening my frontend, backend, and software architecture skills.

## 🛠️ My Development Focus

| 💻 Frontend & Web | ⚙️ Backend & Data | 🎮 Tools & Games |
| :--- | :--- | :--- |
| Frontend development and user interfaces | Backend architecture and APIs | Git and GitHub workflows |
| JavaScript and modern web technologies | Database design | Game development |

---

<div align="center">

## 🔧 Featured Project: WrenchFlow

### Maintenance Management. Simplified.

WrenchFlow is a software project designed to help maintenance teams manage work orders, coordinate technicians, and improve communication between departments.

</div>

**Planned features:**

- [ ] 🧭 Role-based dashboards
- [ ] 📋 Work order creation and assignment
- [ ] 👷 Technician workflows
- [ ] 🛠️ Maintenance tracking
- [ ] 🌓 Light and dark themes

> **Status:** Early development and architecture planning.

---

## 🎯 My Goals

Build a stable career in software development, create useful applications, and continue growing as a developer while pursuing game development as a creative passion.

## 📫 Connect With Me

- **GitHub:** [github.com/codeguyty](https://github.com/codeguyty)
- **Instagram:** [@CodeGuyTy](https://www.instagram.com/codeguyty/)

---

<div align="center">

### ✨ Building. Learning. Improving. One commit at a time.

</div>
